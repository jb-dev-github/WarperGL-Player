#!/bin/bash
#cd "/home/jhonatan/Programação/processing-3.4"

sh "/home/jhonatan/Programação/processing-3.4/processing-java" --sketch="/home/jhonatan/Projetos/warp/WarperGL_multiprocess/warperGL_player_v002" --force --run
